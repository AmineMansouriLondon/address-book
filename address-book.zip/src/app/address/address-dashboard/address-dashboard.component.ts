import { Component } from '@angular/core';

@Component({
  selector: 'app-address-dashboard',
  templateUrl: './address-dashboard.component.html',
  styleUrl: './address-dashboard.component.scss'
})
export class AddressDashboardComponent {

}
